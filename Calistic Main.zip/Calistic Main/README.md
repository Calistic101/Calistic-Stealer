# Calistic-Stealer
![giphy](https://github.com/Calistic101/Calistic-Stealer/assets/141461695/3921b22a-ee3b-405d-a497-ac8cbfe35dd9)

Free, Open-Source Stealer for Windows.

Calistic Stealer is a fast, lightweight stealer written in C#. The collected data is transferred through discord webhooks.
# Disclaimer
-------------------------------------------------------------------------------------------------------------------------
This program, developed by Calistic, is intended solely for educational purposes, to demonstrate the vulnerabilities of computer systems and to promote awareness of cybersecurity. The program should only be used in controlled environments with explicit permission from the system owner.

While the program may be used to assess the security of computer systems, it should not be used for malicious purposes or any activity that may cause harm or damage to computer systems or networks. Any misuse or illegal activity resulting from the use of this program is strictly prohibited and the responsibility lies solely with the user.

The author of this program is not liable for any damage, harm, or legal consequences resulting from the use or misuse of this program. By using this program, you acknowledge that you understand the potential risks and agree to assume full responsibility for any actions taken using the program.


# Features
--------------------------------------------------------------------------------------------------------------------------
- Captures Passwords from 10+ Browsers.
- Captures Cookies from 10+ Browsers.
- Captures Discord Tokens.
- Captures Roblox Cookies.
- Captures Minecraft Session Files.
- Captures Machine Info.
- Captures Webcam Photos.
- Captures IP Address.
- Captures Screenshot(s) of All Monitors.
- Captures Wallets.
- Captures Telegram Sessions.
- Blocks AV Sites (Buggy).
- Adds itself to Startup.
- Anti-Virtual Machine.
- Obfuscation.
- Self Destruct.

# Customizations
--------------------------------------------------------------------------------------------------------------------------
- Custom Payload Icon.
- Custom Assembly Information.
- Custom File Name.

**Note** 
--------------------------------------------------------------------------------------------------------------------------
**Note**: If you didn't get any result while testing Imperium on yourself, you may try to turn off "Anti VM" as Umbral might have detected your system as a virtual machine

# Stay Updated
--------------------------------------------------------------------------------------------------------------------------

Please consider starring this repository if you found this project useful. By starring this repository, you help others discover it, and it shows the developer how many people are interested in this project. Additionally, click on the "Watch" button located at the top of the repository page to receive notifications for the latest updates and features added to the project. Thank you for your support!
